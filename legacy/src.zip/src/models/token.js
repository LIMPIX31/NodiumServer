import * as mongoose from "mongoose";
import {Schema} from "mongoose";


export const LoginTokenSchema = new Schema({
  user: {
    type: Schema.Types.ObjectId,
    ref: 'User'
  },
  refreshToken: String
})

export const TokenModel = mongoose.model('RefreshToken', LoginTokenSchema);
