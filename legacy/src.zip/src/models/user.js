import {Model, Schema} from "mongoose";
import * as mongoose from "mongoose";
import {Document} from 'mongoose'

export const UserRole = {
  devAdmin: 'devAdmin',
  admin: 'admin',
  player: 'player',
  default: 'default'
}

export const UserSchema = new Schema({
  username: String,
  password: String,
  discord: String,
  avatar: String,
  balance: Number,
  email: {
    email: String,
    verificationCode: String,
    emailVerified: {
      type: Boolean,
      default: false
    }
  },
  createdTime: Number,
  roles: {
    type: [String],
    default: [UserRole.default]
  },
  gameProfile: {
    nickname: String,
    uuid: String,
    nicknameChangeTime: Number,
    skin: String,
    cape: String,
  }
})

export const UserModel = mongoose.model('User', UserSchema);
